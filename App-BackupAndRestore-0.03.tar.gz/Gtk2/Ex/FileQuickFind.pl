#!/usr/bin/perl -w
use strict;
use warnings;

use lib "$ENV{HOME}/perl";

#printf "*** %s\n", $0;

use Gtk2::Ex::FileQuickFind -run;

1;
__END__
